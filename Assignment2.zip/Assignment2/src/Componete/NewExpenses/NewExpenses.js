import "./NewExpenses.css";
import ExpenseForm from "./ExpenseForm";
const NewExpenses = (props) => {
  const saveExpenseHandler = (enterExpenseData) => {
    const expensesData = {
      ...enterExpenseData,
      id: Math.random().toString(),
    };
    //console.log(expensesData);
    props.onAddExpense(expensesData);
  };
  return (
    <div className="new-expense">
      <ExpenseForm onSaveExpensesData={saveExpenseHandler} />
    </div>
  );
};
export default NewExpenses;
